﻿using LinearAlgebra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSC160_ConsoleMenu;

namespace Calculator
{
    class Program
    {
        public static Dictionary<String, Matrix> matrixOptions = new Dictionary<string, Matrix>();

        static void Main(string[] args)
        {
            Meth();
        }

        #region Menus
        public static void Meth()
        {
            Console.Clear();
            int min = 2;
            int max = 10;
            AddMatrixes(CIO.PromptForInt("How many matrixes would you like to start with " + $"[{min}-{max}]", min, max));
            int options = 0;
            do
            {
                Console.Clear();
                options = CIO.PromptForMenuSelection(new String[] { "Matrix Math", "Matrix Functions", "Manage Matrixes" }, true);
                Matrix m = null;
                switch (options)
                {
                    case 1:
                        MatrixMath(m);
                        break;
                    case 2:
                        MatrixFunctions(m);
                        break;
                    case 3:
                        ManageMatrixes();
                        break;
                }
            } while (options != 0);
        }
        public static void ManageMatrixes()
        {
            int choice = 0;
            do
            {
                Console.Clear();
                choice = CIO.PromptForMenuSelection(new String[] { "Add Matrix", "View Matrixes" }, true);
                switch (choice)
                {
                    case 1:
                        AddMatrix(CIO.PromptForInput("Enter a name for your matrix", false));
                        break;
                    case 2:
                        PrintAllMatrixes();
                        break;
                }
                CIO.PromptForInput("Press Enter To Continue...", true);
            } while (choice != 0);
        }
        public static void MatrixFunctions(Matrix m)
        {
            int choice = 0;
            Console.WriteLine("Choose your matrix");
            m = MatrixesInDictionary();
            do
            {
                Console.Clear();
                choice = CIO.PromptForMenuSelection(new String[] { "Transpositions", "Reduced Row Echelon Form (Still in progress...)", "Change Primary Matrix" }, true);
                switch (choice)
                {
                    case 1:
                        Console.WriteLine(m.RotateMatrix());
                        break;
                    case 2:
                        Console.WriteLine("Brother I said its still in progress!!!");
                        break;
                    case 3:
                        m = MatrixesInDictionary();
                        break;
                }
                CIO.PromptForInput("Press Enter To Continue...", true);
            } while (choice != 0);
        }
        public static void MatrixMath(Matrix m)
        {
            int choice = 0;
            Console.WriteLine("Choose your first matrix");
            m = MatrixesInDictionary();
            do
            {
                Console.Clear();
                choice = CIO.PromptForMenuSelection(new String[] { "Addition", "Subtraction", "Multiplication", "Change Primary Matrix" }, true);
                switch (choice)
                {
                    case 1:
                        var m2 = MatrixesInDictionaryWithSameDimensions(m);
                        MatrixAddition(m, m2);
                        break;
                    case 2:
                        m2 = MatrixesInDictionaryWithSameDimensions(m);
                        MatrixSubtraction(m, m2);
                        break;
                    case 3:
                        m2 = MatrixesInDictionaryWithHeight(m);
                        MatrixMultiplication(m, m2);
                        break;
                    case 4:
                        m = MatrixesInDictionary();

                        break;
                }
                CIO.PromptForInput("Press Enter To Continue...", true);
            } while (choice != 0);
        }
        #endregion

        #region Matrix Math Methods
        public static void MatrixAddition(Matrix m, Matrix m2)
        {
            String name = matrixOptions.SingleOrDefault(s => s.Value.Equals(m)).Key;
            String name2 = matrixOptions.SingleOrDefault(s => s.Value.Equals(m2)).Key;
            Console.WriteLine($"{m}\n + \n{m2}");
            Console.WriteLine(m.AddMatrix(m2));
            if (CIO.PromptForBool("Would you like to save the result? [y/n]", "y", "n"))
                AddMatrix($"{name} + {name2}", m.AddMatrix(m2));
        }
        public static void MatrixSubtraction(Matrix m, Matrix m2)
        {
            String name = matrixOptions.SingleOrDefault(s => s.Value.Equals(m)).Key;
            String name2 = matrixOptions.SingleOrDefault(s => s.Value.Equals(m2)).Key;
            int sub = CIO.PromptForMenuSelection(new String[] { $"{name} - {name2}\n", $"{name2} - {name}\n" }, false);
            if (sub == 1)
            {
                Console.WriteLine($"{m}\n - \n{m2}");
                Console.WriteLine(m.AddMatrix(m2.Scale(-1)));
                if (CIO.PromptForBool("Would you like to save the result? [y/n]", "y", "n"))
                    AddMatrix($"{name} - {name2}", m.AddMatrix(m2.Scale(-1)));
            }
            else
            {
                Console.WriteLine($"{m2}\n - \n{m}");
                Console.WriteLine(m2.AddMatrix(m.Scale(-1)));
                if (CIO.PromptForBool("Would you like to save the result? [y/n]", "y", "n"))
                    AddMatrix($"{name2} - {name}", m2.AddMatrix(m.Scale(-1)));
            }

        }
        public static void MatrixMultiplication(Matrix m, Matrix m2)
        {
            String name = matrixOptions.SingleOrDefault(s => s.Value.Equals(m)).Key;
            String name2 = matrixOptions.SingleOrDefault(s => s.Value.Equals(m2)).Key;
            int sub = CIO.PromptForMenuSelection(new String[] { $"{name} * {name2}\n", $"{name2} * {name}\n" }, false);
            if (sub == 1)
            {
                Console.WriteLine($"{m}\n * \n{m2}");
                Console.WriteLine(m.DotMatrix(m2));
                if (CIO.PromptForBool("Would you like to save the result? [y/n]", "y", "n"))
                    AddMatrix($"{name} * {name2}", m.DotMatrix(m2));
            }
            else
            {
                Console.WriteLine($"{m2}\n * \n{m}");
                Console.WriteLine(m2.DotMatrix(m));
                if (CIO.PromptForBool("Would you like to save the result? [y/n]", "y", "n"))
                    AddMatrix($"{name2} * {name}", m2.DotMatrix(m));
            }

        }
        #endregion

        #region Matrix Print Methods / Search Methods
        public static void PrintAllMatrixes()
        {
            foreach (var item in matrixOptions)
            {
                Console.WriteLine($"Name: {item.Key}");
                Console.WriteLine(item.Value + "\n\n");
            }
        }
        public static Matrix MatrixesInDictionary()
        {
            return ChooseMatrix(matrixOptions.Keys.ToList()[CIO.PromptForMenuSelection(matrixOptions.Select(s => $"{s.Key}:  \n{s.Value}\n\n"), false) - 1]);
        }
        public static Matrix MatrixesInDictionaryWithSameDimensions(Matrix m)
        {
            return ChooseMatrix(matrixOptions.Keys.ToList().Where(s => !matrixOptions[s].Equals(m) && matrixOptions[s].Width == m.Width && matrixOptions[s].Height == m.Height).ToList()[CIO.PromptForMenuSelection(matrixOptions.Where(s => !matrixOptions[s.Key].Equals(m) && matrixOptions[s.Key].Width == m.Width && matrixOptions[s.Key].Height == m.Height).ToList().Select(s => $"{s.Key} - \n{s.Value}\n\n"), false) - 1]);
        }
        public static Matrix ChooseMatrix(String key)
        {
            if (matrixOptions.ContainsKey(key))
                return matrixOptions[key];
            return null;
        }
        public static Matrix MatrixesInDictionaryWithHeight(Matrix m)
        {
            return ChooseMatrix(matrixOptions.Keys.ToList().Where(s => !matrixOptions[s].Equals(m) && matrixOptions[s].Height == m.Height).ToList()[CIO.PromptForMenuSelection(matrixOptions.Where(s => !matrixOptions[s.Key].Equals(m) && matrixOptions[s.Key].Height == m.Height).ToList().Select(s => $"{s.Key} - \n{s.Value}\n\n"), false) - 1]);
        }
        #endregion

        #region Adding Matrix to Dictionary
        public static void AddMatrixes(int numOfMatrixes)
        {
            for (int i = 0; i < numOfMatrixes; i++)
            {
                AddMatrix(CIO.PromptForInput("Enter the name of your matrix", false));
                Console.Clear();
            }
        }        
        public static void AddMatrix(String key, Matrix matrix)
        {
            if (matrixOptions.ContainsKey(key))
            {
                Console.WriteLine("Key already exists");
            }
            else
            {
                matrixOptions.Add(key, matrix);
            }

            Console.Clear();
            Console.WriteLine($"This is matrix {key}: ");
            Console.WriteLine(matrixOptions[key]);
            CIO.PromptForInput("Please press enter to continue...", true);
        }
        public static void AddMatrix(String key)
        {
            while (matrixOptions.ContainsKey(key))
            {
                Console.WriteLine("Key already exists");
                key = CIO.PromptForInput("Enter a new name for your matrix", false);
            }
            var m = new Matrix(BuildMatrix(CIO.PromptForInt("Number of rows for your matrix", 1, 10)));
            bool redo = true;
            do
            {
                if (matrixOptions.Values.Where(s => s.Equals(m)).ToList().Count == 0)
                {
                    matrixOptions.Add(key, m);
                    Console.Clear();
                    Console.WriteLine($"This is matrix {key}: ");
                    Console.WriteLine(matrixOptions[key]);
                    redo = false;
                }
                else
                {
                    Console.WriteLine("Matrix with those values already exists.");
                    m = new Matrix(BuildMatrix(CIO.PromptForInt("Number of rows for your matrix", 1, 10)));
                }
            } while (redo);
        }
        #endregion

        #region Building Matrix Methods
        public static List<Vector> BuildMatrix(int rows)
        {
            var m = new List<Vector>();
            int col = CIO.PromptForInt("How many columns will be in the matrix", 1, 10);
            while (rows-- > 0)
            {
                m.Add(BuildVector(col));
            }
            return m;
        }
        public static Vector BuildVector(int col)
        {
            var v = new Vector(GetRow(col));
            return v;
        }
        public static List<double> GetRow(int col)
        {
            var x = new List<double>();
            Console.WriteLine("Example of entry: 1, 2, 3");
            do
            {
                if (x.Count < col || x.Count > col)
                    Console.WriteLine($"You must enter {col} columns");
                x = ParseNumbers(CIO.PromptForInput("", false));
            } while (x.Count != col);
            return x;
        }
        public static List<double> ParseNumbers(string word)
        {
            List<double> vectorNums = new List<double>();
            foreach (var number in word.Replace(" ", "").Split(','))
            {
                double.TryParse(number, out double num);
                vectorNums.Add(num);
            }
            return vectorNums;
        }
        #endregion
    }
}
